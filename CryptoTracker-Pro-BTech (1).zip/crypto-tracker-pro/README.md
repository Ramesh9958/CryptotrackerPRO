# CryptoTracker Pro

A production-style 4th-year B.Tech full-stack cryptocurrency tracker built with React + Vite, Node.js + Express, MongoDB, JWT authentication, CoinGecko market data, charts, watchlists, portfolio tracking, price alerts, search, caching, rate limiting, and Docker support.

## Features

- Live cryptocurrency market dashboard
- Search and sort coins
- Coin detail pages with historical charts
- User registration/login with JWT
- Watchlist
- Virtual portfolio with buy/sell transactions
- Portfolio P&L calculation
- Price alerts
- Dashboard statistics
- Dark/light responsive UI
- Backend API proxy so API credentials stay server-side
- In-memory market-data caching to reduce external API calls
- Helmet, CORS, compression and rate limiting
- MongoDB persistence
- Docker and Render deployment configuration
- Vercel-friendly frontend configuration

## Stack

Frontend: React 18, Vite, React Router, Axios, Recharts, Lucide React  
Backend: Node.js, Express, Mongoose, JWT, bcryptjs  
Database: MongoDB / MongoDB Atlas  
Market data: CoinGecko API

## Local setup

### 1. Requirements

- Node.js 20+
- npm 10+
- MongoDB locally OR a MongoDB Atlas connection string
- Optional CoinGecko Demo API key

### 2. Backend

```bash
cd server
npm install
copy .env.example .env
npm run dev
```

Linux/macOS:
```bash
cp .env.example .env
npm install
npm run dev
```

Edit `.env`:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/crypto_tracker
JWT_SECRET=replace-with-a-long-random-secret
CLIENT_URL=http://localhost:5173
COINGECKO_API_KEY=
COINGECKO_BASE_URL=https://api.coingecko.com/api/v3
```

### 3. Frontend

Open another terminal:

```bash
cd client
npm install
copy .env.example .env
npm run dev
```

Linux/macOS:
```bash
cp .env.example .env
npm install
npm run dev
```

The frontend runs at http://localhost:5173 and the API at http://localhost:5000.

## Production build

```bash
cd client
npm run build
```

The generated `client/dist` can be deployed as a static site.

## API overview

- GET `/api/health`
- GET `/api/market/coins`
- GET `/api/market/trending`
- GET `/api/market/global`
- GET `/api/market/coin/:id`
- GET `/api/market/coin/:id/chart?days=30`
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`
- GET/POST/DELETE `/api/watchlist`
- GET/POST/DELETE `/api/portfolio`
- GET/POST/DELETE `/api/alerts`

Authenticated endpoints require:
`Authorization: Bearer <JWT>`

## Deployment

### Option A — Render

The included `render.yaml` can deploy the backend as a Node web service. Create a MongoDB Atlas database and add `MONGO_URI`, `JWT_SECRET`, `CLIENT_URL`, and optional CoinGecko API key as environment variables.

Render web services must listen on the platform `PORT`; this project does that automatically.

### Option B — Vercel frontend + Render backend

Deploy `client` to Vercel and set:

```env
VITE_API_URL=https://YOUR-BACKEND.onrender.com/api
```

Deploy `server` to Render and set:

```env
CLIENT_URL=https://YOUR-FRONTEND.vercel.app
```

### Option C — Docker

From the project root:

```bash
docker compose up --build
```

Frontend: http://localhost:8080  
Backend: http://localhost:5000

## Important

Never commit `.env` files. Use environment variables on deployment platforms.

Coin prices are market data and can be delayed or rate-limited. This application is an educational portfolio project, not financial advice.
