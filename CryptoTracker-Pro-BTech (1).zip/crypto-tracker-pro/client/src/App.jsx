import { useEffect, useMemo, useState } from 'react';
import { Routes, Route, Link, useNavigate, useParams } from 'react-router-dom';
import { BarChart3, Bell, Bookmark, LogIn, LogOut, Moon, Search, Star, Sun, Wallet, TrendingUp, UserPlus, Trash2 } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from 'recharts';
import api from './api';

const money = (n, digits = 2) => {
  const value = Number(n);
  if (!Number.isFinite(value)) return '—';
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: digits }).format(value);
};

const pct = (n) => `${Number(n) >= 0 ? '+' : ''}${Number(n || 0).toFixed(2)}%`;

function Layout({ children, user, onLogout, dark, setDark }) {
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link className="brand" to="/"><TrendingUp size={22}/> CryptoTracker <span>PRO</span></Link>
        <nav>
          <Link to="/">Markets</Link>
          {user && <><Link to="/portfolio">Portfolio</Link><Link to="/watchlist">Watchlist</Link><Link to="/alerts">Alerts</Link></>}
          <button className="icon-btn" onClick={() => setDark(!dark)} title="Toggle theme">{dark ? <Sun size={18}/> : <Moon size={18}/>}</button>
          {user ? <button className="nav-btn" onClick={onLogout}><LogOut size={16}/> Logout</button> : <><Link className="nav-btn" to="/login"><LogIn size={16}/> Login</Link><Link className="nav-btn primary" to="/register"><UserPlus size={16}/> Register</Link></>}
        </nav>
      </header>
      <main className="container">{children}</main>
      <footer>CryptoTracker Pro • Educational project • Market data powered by CoinGecko</footer>
    </div>
  );
}

function MarketCard({ coin, watchlisted, onWatch }) {
  const change = coin.price_change_percentage_24h;
  return (
    <div className="coin-card">
      <div className="coin-head">
        <img src={coin.image} alt="" />
        <div><strong>{coin.name}</strong><small>{coin.symbol?.toUpperCase()}</small></div>
        <button className={`star ${watchlisted ? 'active' : ''}`} onClick={() => onWatch(coin)}><Star size={18} fill={watchlisted ? 'currentColor' : 'none'}/></button>
      </div>
      <Link to={`/coin/${coin.id}`} className="coin-link">
        <div className="coin-price">{money(coin.current_price, coin.current_price < 1 ? 4 : 2)}</div>
        <div className={change >= 0 ? 'positive' : 'negative'}>{pct(change)} 24h</div>
      </Link>
      <div className="spark">
        <ResponsiveContainer width="100%" height={50}>
          <LineChart data={(coin.sparkline_in_7d?.price || []).filter((_, i) => i % 8 === 0).map((v, i) => ({ i, v }))}>
            <Line type="monotone" dataKey="v" stroke="currentColor" dot={false} strokeWidth={2}/>
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div className="muted">Market cap {money(coin.market_cap, 0)}</div>
    </div>
  );
}

function Dashboard({ user, onLogout, dark, setDark }) {
  const [coins, setCoins] = useState([]);
  const [global, setGlobal] = useState(null);
  const [watch, setWatch] = useState([]);
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('market_cap_desc');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  async function load() {
    try {
      setLoading(true);
      setError('');
      const [market, globalRes] = await Promise.all([
        api.get('/market/coins', { params: { perPage: 50, order: sort } }),
        api.get('/market/global')
      ]);
      setCoins(market.data);
      setGlobal(globalRes.data.data);
      if (user) {
        const w = await api.get('/watchlist');
        setWatch(w.data);
      }
    } catch (e) {
      setError(e.response?.data?.message || 'Unable to load market data.');
    } finally { setLoading(false); }
  }

  useEffect(() => { load(); }, [sort, user?.id]);

  async function toggleWatch(coin) {
    if (!user) return alert('Please login to use your watchlist.');
    const exists = watch.some(x => x.coinId === coin.id);
    try {
      if (exists) await api.delete(`/watchlist/${coin.id}`);
      else await api.post('/watchlist', { coinId: coin.id, symbol: coin.symbol, name: coin.name });
      setWatch(exists ? watch.filter(x => x.coinId !== coin.id) : [...watch, { coinId: coin.id }]);
    } catch (e) { alert(e.response?.data?.message || 'Watchlist action failed'); }
  }

  const filtered = useMemo(() => coins.filter(c =>
    `${c.name} ${c.symbol}`.toLowerCase().includes(query.toLowerCase())
  ), [coins, query]);

  return <Layout user={user} onLogout={onLogout} dark={dark} setDark={setDark}>
    <section className="hero">
      <div><p className="eyebrow">REAL-TIME MARKET INTELLIGENCE</p><h1>Crypto market, <span>simplified.</span></h1><p className="subtitle">Track prices, analyze trends, build a virtual portfolio and create personalized price alerts.</p></div>
    </section>

    {global && <div className="stats">
      <div><span>Total market cap</span><strong>{money(global.total_market_cap?.usd, 0)}</strong></div>
      <div><span>24h volume</span><strong>{money(global.total_volume?.usd, 0)}</strong></div>
      <div><span>BTC dominance</span><strong>{Number(global.market_cap_percentage?.btc || 0).toFixed(2)}%</strong></div>
      <div><span>Active cryptocurrencies</span><strong>{global.active_cryptocurrencies?.toLocaleString()}</strong></div>
    </div>}

    <div className="toolbar">
      <div className="search"><Search size={18}/><input placeholder="Search coins..." value={query} onChange={e => setQuery(e.target.value)}/></div>
      <select value={sort} onChange={e => setSort(e.target.value)}>
        <option value="market_cap_desc">Market cap</option>
        <option value="volume_desc">Volume</option>
        <option value="price_change_percentage_24h_desc">24h gainers</option>
        <option value="price_change_percentage_24h_asc">24h losers</option>
      </select>
    </div>

    {error && <div className="alert error">{error}</div>}
    {loading ? <div className="loading">Loading live market data…</div> :
      <div className="coin-grid">{filtered.map(c => <MarketCard key={c.id} coin={c} watchlisted={watch.some(w => w.coinId === c.id)} onWatch={toggleWatch}/>)}</div>}
  </Layout>;
}

function Auth({ mode, onLogin }) {
  const register = mode === 'register';
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      const res = await api.post(`/auth/${register ? 'register' : 'login'}`, form);
      localStorage.setItem('crypto_token', res.data.token);
      onLogin(res.data.user);
      navigate('/');
    } catch (err) { setError(err.response?.data?.message || 'Request failed'); }
  }

  return <div className="auth-wrap"><form className="auth-card" onSubmit={submit}>
    <TrendingUp size={30}/><h2>{register ? 'Create account' : 'Welcome back'}</h2><p className="muted">{register ? 'Start tracking your crypto portfolio.' : 'Login to your personal dashboard.'}</p>
    {register && <input placeholder="Full name" required value={form.name} onChange={e => setForm({...form, name: e.target.value})}/>}
    <input type="email" placeholder="Email" required value={form.email} onChange={e => setForm({...form, email: e.target.value})}/>
    <input type="password" placeholder="Password" minLength="6" required value={form.password} onChange={e => setForm({...form, password: e.target.value})}/>
    {error && <div className="alert error">{error}</div>}
    <button className="primary big">{register ? 'Create account' : 'Login'}</button>
    <p className="muted">{register ? 'Already registered?' : 'New here?'} <Link to={register ? '/login' : '/register'}>{register ? 'Login' : 'Create an account'}</Link></p>
  </form></div>;
}

function CoinDetails({ user }) {
  const { id } = useParams();
  const [coin, setCoin] = useState(null);
  const [chart, setChart] = useState([]);
  const [days, setDays] = useState('30');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.get(`/market/coin/${id}`), api.get(`/market/coin/${id}/chart`, { params: { days } })])
      .then(([a,b]) => {
        setCoin(a.data);
        setChart(b.data.prices.map(([time, price]) => ({ time, price })));
      }).finally(() => setLoading(false));
  }, [id, days]);

  if (loading || !coin) return <Layout user={user}><div className="loading">Loading coin…</div></Layout>;

  const md = coin.market_data;
  const chartData = chart.filter((_, i) => i % Math.max(1, Math.floor(chart.length / 100)) === 0);

  return <Layout user={user}>
    <Link to="/" className="back">← Back to markets</Link>
    <div className="detail-head">
      <img src={coin.image?.large} alt="" /><div><h1>{coin.name} <small>{coin.symbol?.toUpperCase()}</small></h1><div className="coin-price">{money(md.current_price.usd, md.current_price.usd < 1 ? 6 : 2)}</div><div className={md.price_change_percentage_24h >= 0 ? 'positive' : 'negative'}>{pct(md.price_change_percentage_24h)} today</div></div>
    </div>
    <div className="chart-card">
      <div className="toolbar"><h3>Price history</h3><select value={days} onChange={e => setDays(e.target.value)}><option value="1">24 hours</option><option value="7">7 days</option><option value="30">30 days</option><option value="90">90 days</option><option value="365">1 year</option></select></div>
      <ResponsiveContainer width="100%" height={360}><LineChart data={chartData}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="time" tickFormatter={v => new Date(v).toLocaleDateString()} minTickGap={40}/><YAxis tickFormatter={v => `$${Number(v).toLocaleString()}`}/><Tooltip labelFormatter={v => new Date(v).toLocaleString()} formatter={v => [money(v), 'Price']}/><Line type="monotone" dataKey="price" stroke="currentColor" dot={false} strokeWidth={2}/></LineChart></ResponsiveContainer>
    </div>
    <div className="stats">
      <div><span>Market cap</span><strong>{money(md.market_cap.usd, 0)}</strong></div>
      <div><span>24h high</span><strong>{money(md.high_24h.usd)}</strong></div>
      <div><span>24h low</span><strong>{money(md.low_24h.usd)}</strong></div>
      <div><span>Circulating supply</span><strong>{Number(md.circulating_supply || 0).toLocaleString()}</strong></div>
    </div>
  </Layout>;
}

function Portfolio({ user }) {
  const [items, setItems] = useState([]);
  const [prices, setPrices] = useState({});
  const [form, setForm] = useState({ coinId: 'bitcoin', symbol: 'btc', name: 'Bitcoin', quantity: '', buyPrice: '' });
  const [coins, setCoins] = useState([]);

  async function load() {
    const [p, m] = await Promise.all([api.get('/portfolio'), api.get('/market/coins', { params: { perPage: 100 } })]);
    setItems(p.data); setCoins(m.data);
    setPrices(Object.fromEntries(m.data.map(c => [c.id, c.current_price])));
  }
  useEffect(() => { load(); }, []);

  async function add(e) {
    e.preventDefault();
    await api.post('/portfolio', form);
    setForm({...form, quantity: '', buyPrice: ''});
    load();
  }

  const total = items.reduce((s, x) => s + x.quantity * (prices[x.coinId] || x.averageBuyPrice), 0);
  const invested = items.reduce((s, x) => s + x.quantity * x.averageBuyPrice, 0);
  const pnl = total - invested;

  return <Layout user={user}>
    <div className="page-title"><div><p className="eyebrow">PERSONAL FINANCE SIMULATOR</p><h1>Portfolio</h1></div></div>
    <div className="stats"><div><span>Current value</span><strong>{money(total)}</strong></div><div><span>Invested</span><strong>{money(invested)}</strong></div><div><span>Unrealized P&L</span><strong className={pnl >= 0 ? 'positive' : 'negative'}>{money(pnl)}</strong></div></div>
    <form className="form-row" onSubmit={add}>
      <select value={form.coinId} onChange={e => { const c=coins.find(x=>x.id===e.target.value); setForm({...form, coinId:c.id, symbol:c.symbol, name:c.name}); }}>
        {coins.map(c => <option key={c.id} value={c.id}>{c.name} ({c.symbol.toUpperCase()})</option>)}
      </select>
      <input type="number" step="any" min="0.00000001" placeholder="Quantity" required value={form.quantity} onChange={e=>setForm({...form,quantity:e.target.value})}/>
      <input type="number" step="any" min="0" placeholder="Buy price ($)" required value={form.buyPrice} onChange={e=>setForm({...form,buyPrice:e.target.value})}/>
      <button className="primary">Add holding</button>
    </form>
    <div className="table-wrap"><table><thead><tr><th>Asset</th><th>Quantity</th><th>Avg buy</th><th>Current</th><th>P&L</th><th></th></tr></thead><tbody>
      {items.map(x => { const current=prices[x.coinId] || x.averageBuyPrice; const value=x.quantity*current; const profit=value-x.quantity*x.averageBuyPrice; return <tr key={x._id}><td><strong>{x.name}</strong><small>{x.symbol.toUpperCase()}</small></td><td>{x.quantity}</td><td>{money(x.averageBuyPrice)}</td><td>{money(current)}</td><td className={profit>=0?'positive':'negative'}>{money(profit)}</td><td><button className="danger-icon" onClick={async()=>{await api.delete(`/portfolio/${x.coinId}`);load();}}><Trash2 size={16}/></button></td></tr>})}
    </tbody></table></div>
  </Layout>;
}

function Watchlist({ user }) {
  const [items,setItems]=useState([]);
  const [market,setMarket]=useState([]);
  async function load(){ const [w,m]=await Promise.all([api.get('/watchlist'),api.get('/market/coins',{params:{perPage:100}})]); setItems(w.data);setMarket(m.data); }
  useEffect(()=>{load()},[]);
  const coins=items.map(w=>market.find(c=>c.id===w.coinId)).filter(Boolean);
  return <Layout user={user}><div className="page-title"><div><p className="eyebrow">YOUR SHORTLIST</p><h1>Watchlist</h1></div><Bookmark/></div>{coins.length?<div className="coin-grid">{coins.map(c=><MarketCard key={c.id} coin={c} watchlisted onWatch={async()=>{await api.delete(`/watchlist/${c.id}`);load();}}/>)}</div>:<div className="empty">No watchlisted assets yet. Star a coin on the market page.</div>}</Layout>;
}

function Alerts({ user }) {
  const [items,setItems]=useState([]);
  const [form,setForm]=useState({coinId:'bitcoin',symbol:'btc',targetPrice:'',direction:'above'});
  const [coins,setCoins]=useState([]);
  async function load(){const [a,m]=await Promise.all([api.get('/alerts'),api.get('/market/coins',{params:{perPage:100}})]);setItems(a.data);setCoins(m.data);}
  useEffect(()=>{load()},[]);
  async function add(e){e.preventDefault();await api.post('/alerts',form);setForm({...form,targetPrice:''});load();}
  return <Layout user={user}><div className="page-title"><div><p className="eyebrow">AUTOMATED MONITORING</p><h1>Price Alerts</h1></div><Bell/></div>
    <form className="form-row" onSubmit={add}><select value={form.coinId} onChange={e=>{const c=coins.find(x=>x.id===e.target.value);setForm({...form,coinId:c.id,symbol:c.symbol})}}>{coins.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select><select value={form.direction} onChange={e=>setForm({...form,direction:e.target.value})}><option value="above">Rises above</option><option value="below">Falls below</option></select><input type="number" step="any" placeholder="Target price" required value={form.targetPrice} onChange={e=>setForm({...form,targetPrice:e.target.value})}/><button className="primary">Create alert</button></form>
    <div className="alert-list">{items.map(a=><div className="alert-row" key={a._id}><Bell size={18}/><strong>{a.symbol.toUpperCase()}</strong><span>{a.direction} {money(a.targetPrice)}</span><button className="danger-icon" onClick={async()=>{await api.delete(`/alerts/${a._id}`);load();}}><Trash2 size={16}/></button></div>)}</div>
  </Layout>;
}

export default function App() {
  const [user,setUser]=useState(null);
  const [dark,setDark]=useState(()=>localStorage.getItem('crypto_theme')==='dark');

  useEffect(()=>{
    document.documentElement.dataset.theme=dark?'dark':'light';
    localStorage.setItem('crypto_theme',dark?'dark':'light');
    const token=localStorage.getItem('crypto_token');
    if(token) api.get('/auth/me').then(r=>setUser(r.data.user)).catch(()=>localStorage.removeItem('crypto_token'));
  },[dark]);

  function logout(){localStorage.removeItem('crypto_token');setUser(null);}

  const common={user,onLogout:logout,dark,setDark};
  return <Routes>
    <Route path="/" element={<Dashboard user={user} onLogout={logout} dark={dark} setDark={setDark}/>}/>
    <Route path="/coin/:id" element={<CoinDetails user={user}/>}/>
    <Route path="/portfolio" element={user?<Portfolio user={user}/>:<Auth mode="login" onLogin={setUser}/>}/>
    <Route path="/watchlist" element={user?<Watchlist user={user}/>:<Auth mode="login" onLogin={setUser}/>}/>
    <Route path="/alerts" element={user?<Alerts user={user}/>:<Auth mode="login" onLogin={setUser}/>}/>
    <Route path="/login" element={<Auth mode="login" onLogin={setUser}/>}/>
    <Route path="/register" element={<Auth mode="register" onLogin={setUser}/>}/>
  </Routes>;
}
