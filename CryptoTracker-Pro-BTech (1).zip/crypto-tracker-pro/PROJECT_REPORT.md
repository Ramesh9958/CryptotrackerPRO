# CryptoTracker Pro — B.Tech Project Guide

## Problem statement
Cryptocurrency markets change continuously, making it difficult for users to monitor prices, compare assets, maintain a personal investment record, and receive meaningful alerts in one place.

## Objectives
1. Build a responsive cryptocurrency market dashboard.
2. Consume third-party market data through a secure backend proxy.
3. Implement user authentication and persistent user-specific data.
4. Provide portfolio analytics and watchlist management.
5. Provide configurable price alerts.
6. Deploy the application using cloud-friendly configuration.
7. Apply practical web-security and performance techniques.

## Modules
- Authentication
- Market data service
- Market dashboard
- Coin analytics
- Watchlist
- Portfolio
- Price alerts
- API security and rate limiting
- Deployment

## Database collections
### User
_id, name, email, passwordHash, timestamps

### Watchlist
userId, coinId, symbol, name, timestamps

### Portfolio
userId, coinId, symbol, name, quantity, averageBuyPrice, timestamps

### Alert
userId, coinId, symbol, targetPrice, direction, active, timestamps

## Data flow
Browser → React UI → Express REST API → CoinGecko / MongoDB → Express → React.

## Security
- Passwords are bcrypt-hashed.
- JWT is used for protected API routes.
- CoinGecko API key is kept on the server.
- Helmet adds common HTTP security headers.
- CORS restricts browser origins.
- Rate limiting reduces abusive API traffic.
- Input values are validated server-side.

## Advanced features to explain in viva
### Caching
Market responses are cached in memory for a short TTL. This lowers repeated third-party requests and improves response time.

### Portfolio calculation
For each holding:
Current value = quantity × current market price

Invested value = quantity × average buy price

Unrealized P&L = current value − invested value

When a user adds to an existing holding, weighted average buy price is recalculated.

### Scalability
For a larger deployment, move cache to Redis, use a scheduled alert worker, add a database index strategy, and separate market ingestion from API serving.

## Suggested future enhancements
- WebSocket real-time updates
- Email/Telegram notifications
- Redis caching
- Background worker for alerts
- Advanced technical indicators (RSI, MACD, moving averages)
- ML-based volatility prediction
- CSV/PDF portfolio export
- Admin analytics dashboard
- OAuth login
- Role-based access control
