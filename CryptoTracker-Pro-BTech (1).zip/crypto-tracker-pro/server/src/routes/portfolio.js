import express from 'express';
import Portfolio from '../models/Portfolio.js';
import { authRequired } from '../middleware/auth.js';

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res, next) => {
  try {
    res.json(await Portfolio.find({ userId: req.user.id }).sort({ createdAt: -1 }));
  } catch (error) { next(error); }
});

router.post('/', async (req, res, next) => {
  try {
    const { coinId, symbol, name, quantity, buyPrice } = req.body;
    const qty = Number(quantity);
    const price = Number(buyPrice);

    if (!coinId || !symbol || !name || !Number.isFinite(qty) || !Number.isFinite(price) || qty <= 0 || price < 0) {
      return res.status(400).json({ message: 'Valid coin, quantity and buy price are required' });
    }

    const existing = await Portfolio.findOne({ userId: req.user.id, coinId });

    if (!existing) {
      const item = await Portfolio.create({
        userId: req.user.id, coinId, symbol, name,
        quantity: qty, averageBuyPrice: price
      });
      return res.status(201).json(item);
    }

    const totalCost = existing.quantity * existing.averageBuyPrice + qty * price;
    existing.quantity += qty;
    existing.averageBuyPrice = totalCost / existing.quantity;
    await existing.save();

    res.json(existing);
  } catch (error) { next(error); }
});

router.delete('/:coinId', async (req, res, next) => {
  try {
    await Portfolio.deleteOne({ userId: req.user.id, coinId: req.params.coinId });
    res.json({ message: 'Holding removed' });
  } catch (error) { next(error); }
});

export default router;
