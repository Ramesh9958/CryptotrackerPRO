import express from 'express';
import Alert from '../models/Alert.js';
import { authRequired } from '../middleware/auth.js';

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res, next) => {
  try {
    res.json(await Alert.find({ userId: req.user.id }).sort({ createdAt: -1 }));
  } catch (error) { next(error); }
});

router.post('/', async (req, res, next) => {
  try {
    const { coinId, symbol, targetPrice, direction } = req.body;
    const price = Number(targetPrice);

    if (!coinId || !symbol || !Number.isFinite(price) || price <= 0 || !['above', 'below'].includes(direction)) {
      return res.status(400).json({ message: 'Valid coin, target price and direction are required' });
    }

    const alert = await Alert.create({
      userId: req.user.id, coinId, symbol, targetPrice: price, direction
    });
    res.status(201).json(alert);
  } catch (error) { next(error); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await Alert.deleteOne({ _id: req.params.id, userId: req.user.id });
    res.json({ message: 'Alert deleted' });
  } catch (error) { next(error); }
});

export default router;
