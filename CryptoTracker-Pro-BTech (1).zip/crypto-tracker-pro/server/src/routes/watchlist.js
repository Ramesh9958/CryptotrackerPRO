import express from 'express';
import Watchlist from '../models/Watchlist.js';
import { authRequired } from '../middleware/auth.js';

const router = express.Router();
router.use(authRequired);

router.get('/', async (req, res, next) => {
  try {
    res.json(await Watchlist.find({ userId: req.user.id }).sort({ createdAt: -1 }));
  } catch (error) { next(error); }
});

router.post('/', async (req, res, next) => {
  try {
    const { coinId, symbol, name } = req.body;
    if (!coinId) return res.status(400).json({ message: 'coinId is required' });

    const item = await Watchlist.findOneAndUpdate(
      { userId: req.user.id, coinId },
      { userId: req.user.id, coinId, symbol, name },
      { new: true, upsert: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(item);
  } catch (error) { next(error); }
});

router.delete('/:coinId', async (req, res, next) => {
  try {
    await Watchlist.deleteOne({ userId: req.user.id, coinId: req.params.coinId });
    res.json({ message: 'Removed from watchlist' });
  } catch (error) { next(error); }
});

export default router;
