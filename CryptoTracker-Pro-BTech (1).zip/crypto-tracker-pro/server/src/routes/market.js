import express from 'express';
import { getMarkets, getTrending, getGlobal, getCoin, getChart } from '../services/coingecko.js';

const router = express.Router();

router.get('/coins', async (req, res, next) => {
  try {
    const data = await getMarkets(req.query);
    res.json(data);
  } catch (error) {
    next(error);
  }
});

router.get('/trending', async (req, res, next) => {
  try {
    res.json(await getTrending());
  } catch (error) {
    next(error);
  }
});

router.get('/global', async (req, res, next) => {
  try {
    res.json(await getGlobal());
  } catch (error) {
    next(error);
  }
});

router.get('/coin/:id', async (req, res, next) => {
  try {
    res.json(await getCoin(req.params.id));
  } catch (error) {
    next(error);
  }
});

router.get('/coin/:id/chart', async (req, res, next) => {
  try {
    res.json(await getChart(req.params.id, req.query.days, req.query.vs_currency || 'usd'));
  } catch (error) {
    next(error);
  }
});

export default router;
