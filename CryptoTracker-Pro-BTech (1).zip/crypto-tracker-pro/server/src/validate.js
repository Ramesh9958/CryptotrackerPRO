import fs from 'fs';
import path from 'path';
const required = [
  'src/server.js','src/middleware/auth.js','src/services/coingecko.js',
  'src/routes/auth.js','src/routes/market.js','src/routes/watchlist.js',
  'src/routes/portfolio.js','src/routes/alerts.js',
  'src/models/User.js','src/models/Watchlist.js','src/models/Portfolio.js','src/models/Alert.js'
];
for (const file of required) {
  if (!fs.existsSync(path.resolve(file))) throw new Error(`Missing ${file}`);
}
console.log('Backend project structure validation passed.');
