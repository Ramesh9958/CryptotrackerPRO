import axios from 'axios';

const BASE_URL = process.env.COINGECKO_BASE_URL || 'https://api.coingecko.com/api/v3';
const cache = new Map();

function getHeaders() {
  const key = process.env.COINGECKO_API_KEY;
  return key ? { 'x-cg-demo-api-key': key } : {};
}

async function cachedGet(path, params = {}, ttlMs = 30000) {
  const key = `${path}?${new URLSearchParams(params).toString()}`;
  const now = Date.now();
  const hit = cache.get(key);

  if (hit && now - hit.time < ttlMs) return hit.data;

  const response = await axios.get(`${BASE_URL}${path}`, {
    params,
    headers: getHeaders(),
    timeout: 12000
  });

  cache.set(key, { time: now, data: response.data });

  if (cache.size > 100) {
    const oldestKey = cache.keys().next().value;
    cache.delete(oldestKey);
  }

  return response.data;
}

export function getMarkets({ vsCurrency = 'usd', page = 1, perPage = 50, order = 'market_cap_desc', search = '' }) {
  const params = {
    vs_currency: vsCurrency,
    order,
    per_page: Math.min(Math.max(Number(perPage) || 50, 1), 100),
    page: Math.max(Number(page) || 1, 1),
    sparkline: true,
    price_change_percentage: '1h,24h,7d'
  };
  if (search) params.ids = search;
  return cachedGet('/coins/markets', params, 30000);
}

export function getTrending() {
  return cachedGet('/search/trending', {}, 60000);
}

export function getGlobal() {
  return cachedGet('/global', {}, 60000);
}

export function getCoin(id) {
  return cachedGet(`/coins/${encodeURIComponent(id)}`, {
    localization: false,
    tickers: false,
    market_data: true,
    community_data: false,
    developer_data: false
  }, 60000);
}

export function getChart(id, days = 30, vsCurrency = 'usd') {
  const safeDays = ['1', '7', '30', '90', '365', 'max'].includes(String(days))
    ? String(days) : '30';

  return cachedGet(`/coins/${encodeURIComponent(id)}/market_chart`, {
    vs_currency: vsCurrency,
    days: safeDays
  }, 60000);
}
