import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  coinId: { type: String, required: true, trim: true },
  symbol: String,
  name: String
}, { timestamps: true });

schema.index({ userId: 1, coinId: 1 }, { unique: true });

export default mongoose.model('Watchlist', schema);
