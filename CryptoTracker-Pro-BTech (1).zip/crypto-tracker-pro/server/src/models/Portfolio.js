import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  coinId: { type: String, required: true, trim: true },
  symbol: { type: String, required: true },
  name: { type: String, required: true },
  quantity: { type: Number, required: true, min: 0 },
  averageBuyPrice: { type: Number, required: true, min: 0 }
}, { timestamps: true });

schema.index({ userId: 1, coinId: 1 }, { unique: true });

export default mongoose.model('Portfolio', schema);
