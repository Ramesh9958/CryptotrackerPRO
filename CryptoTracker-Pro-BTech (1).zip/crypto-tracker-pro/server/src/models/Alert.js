import mongoose from 'mongoose';

const schema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  coinId: { type: String, required: true },
  symbol: { type: String, required: true },
  targetPrice: { type: Number, required: true, min: 0 },
  direction: { type: String, enum: ['above', 'below'], required: true },
  active: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model('Alert', schema);
